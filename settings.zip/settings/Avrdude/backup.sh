#!/bin/bash
MCU=m328p
PROGRAMMER=pickit2
FILENAME=uno
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U flash:r:"$FILENAME"_flash.hex:i
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U eeprom:r:"$FILENAME"_eeprom.hex:i
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U hfuse:r:"$FILENAME"_hfuse.hex:i
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U lfuse:r:"$FILENAME"_lfuse.hex:i
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U efuse:r:"$FILENAME"_efuse.hex:i
