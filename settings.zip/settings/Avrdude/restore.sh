#!/bin/bash
MCU=m328p
PROGRAMMER=pickit2
FILENAME=uno
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U flash:w:"$FILENAME"_flash.hex:i
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U eeprom:w:"$FILENAME"_eeprom.hex:i
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U hfuse:w:"$FILENAME"_hfuse.hex:i
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U lfuse:w:"$FILENAME"_lfuse.hex:i
avrdude -p "$MCU" -P usb -c "$PROGRAMMER" -U efuse:w:"$FILENAME"_efuse.hex:i
