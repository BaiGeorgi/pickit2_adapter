#!/bin/bash
# pickit2_spi programmer
# An optional voltage parameter specifies the voltage the PICkit2 should use.
# The default unit is Volt if no unit is specified.
# You can use mV, millivolt, V or Volt as unit specifier. Syntax is
#
# flashrom -p pickit2_spi:voltage=value
#
# where value can be 0V, 1.8V, 2.5V, 3.5V or the equivalent in mV.
#
# An optional spispeed parameter specifies the frequency of the SPI bus. Syntax is
#
# flashrom -p pickit2_spi:spispeed=frequency
#
# where frequency can be 250k, 333k, 500k or 1M (in Hz).
# The default is a frequency of 1 MHz.
flashrom -p pickit2_spi -r pickit2_"$(date +"%Y_%m_%d_%I_%M").rom"
##To write the rom use:
#flashrom -p pickit2_spi -r my_file.rom
